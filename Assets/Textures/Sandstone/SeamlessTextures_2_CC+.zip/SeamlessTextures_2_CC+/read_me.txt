PLEASE NOTE: Do not modify the content of the SeamlessTextures_2 folder!
Watch the "How to install an extension panel in photoshop CC2014 or CC2015" Tutorial video: https://youtu.be/NI5lLtk_7C8

Installing
____________________________

Photoshop CC 2014 / CC-2015

____________________________

1. Open Photoshop, goto File > Scripts > Browse...


2. Browse to the unzipped SeamlessTextures_2 folder and select the SeamlessTextures_2-installer.jsx
3. Follow the instruction
4. Restart Photoshop
5. Browse to Window > Extensions > Seamless Textures - 2


Uninstalling
____________________________

Photoshop CC 2014 / CC-2015

____________________________

1. Open Photoshop, goto File > Scripts > Browse...


2. Browse to and select the SeamlessTextures_2 - UNINSTALLER.jsx
3. Follow the instruction
4. Restart Photoshop

 - Done!


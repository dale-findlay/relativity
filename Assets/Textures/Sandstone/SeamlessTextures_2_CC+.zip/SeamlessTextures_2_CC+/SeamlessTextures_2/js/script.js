jQuery(document).ready(function($){
    $('.checkbox').on('click', function(){
        $(this).toggleClass('active');
    });
});